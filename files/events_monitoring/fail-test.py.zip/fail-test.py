#
# Just test Lambda
#
def lambda_handler(event, context):
    exit(1)
